$(document).foundation()
